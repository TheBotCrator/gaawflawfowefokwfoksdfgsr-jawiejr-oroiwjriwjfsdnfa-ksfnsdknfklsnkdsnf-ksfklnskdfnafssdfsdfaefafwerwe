const Discord = require('discord.js');
const figlet = require('figlet');
const colors = require('colors');
const readline = require('readline');

const config = require('./config.json');
const bot = new Discord.Client(); 

const cmdsArray = [
    "dmall <message>",
    "dmrole <role> <message>"
];

bot.on("ready", () => {
    clear();
});

bot.on("message", (message) => {
    if(config.restrictToID == true && message.author.id != config.id) return;

    if(message.channel.type == "dm") return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();

    if(command == "help"){
        const embed = new Discord.RichEmbed()
        .addField("Info", "Hey!  I noticed you wanted some help ;)  Check this RAW data for help! https://pastebin.com/raw/wsT5Zimr");
        message.channel.send({embed: embed});
    }

    if(command == "dmall") {
        let dmGuild = message.guild;
        let msg = args.join(' ');

        if(!msg || msg.length <= 0) return message.author.send("You did not write a message :smile:");

        dmGuild.members.forEach(member => {
            setTimeout(function(){
                if(member.id == bot.user.id) return;
                console.log(`DMing ${member.user.username}`);
                member.send(`${msg}  ${Math.floor(Math.random() * 9999)}`);
            }, Math.floor(Math.random() * 90000));
        });
    }

    if(command == "dmrole") {
        let role = message.mentions.roles.first();
        let msg = args.join(' ');
        
        if(!role) {
            message.author.send("Not a role :(");
            return;
        }

        if(!msg || msg.length <= 0) {
            message.author.send("Mate, u just dumb now.");
            return;
        }

        role.members.forEach(member => {
            setTimeout(function() {
                if(member.id == bot.user.id) return;
                console.log(`DMing ${member.user.username}`);
                member.send(`${msg} ${Math.floor(Math.random() * 9999)}`);
            }, Math.floor(Math.random() * 90000));
        });
    }
});

bot.on("error", (error) => {
    bot.login(config.token);
});

bot.login(config.token);

function clear() {
    console.clear();
    console.log(figlet.textSync("Lanes Lanes, the Magical Fruit, The more you eat the more you toot!").green);
    console.log("Lanes os1");
    console.log("Your Bot Is Online!");
    console.log(`The Prefix is jastb.`);
}
